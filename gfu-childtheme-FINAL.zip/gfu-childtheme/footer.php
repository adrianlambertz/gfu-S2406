<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package gfu
 */

?>

	<footer id="colophon" class="site-footer">
		<div class="site-info">

			<?php if( $copyright_textfield = get_option('copyright_textfield') ): ?>
				<div class="copyright">
					&copy; <?php echo date('Y'); ?> <?php esc_attr_e($copyright_textfield); ?>
				</div>
			<?php endif; ?>

			

			<?php /*
			<?php if( get_field('offnungszeiten', 'option') ): ?>
				<div class="opening">
					<?php the_field('offnungszeiten', 'option'); ?>
				</div>
			<?php endif; ?>
			*/ ?>

			<?php if( $oeffnungszeiten_textarea = get_option('oeffnungszeiten_textarea') ): ?>
				<div class="opening">
					<?php echo nl2br( esc_textarea($oeffnungszeiten_textarea) ); ?>
				</div>
			<?php endif; ?>

		</div><!-- .site-info -->
	</footer><!-- #colophon -->
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
