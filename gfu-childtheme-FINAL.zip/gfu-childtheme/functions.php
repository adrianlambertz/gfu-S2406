<?php

if ( ! function_exists( 'gfu_custom_assets' ) ) :
	function gfu_custom_assets() {
		
		// Aus Child Theme reinholen
		wp_enqueue_style( 'gfu-child', get_stylesheet_directory_uri() . '/css/gfu.css', array(), '1.0', 'all' );
		
	}
	add_action( 'wp_enqueue_scripts', 'gfu_custom_assets' );
endif;




function gfu_add_login_css() {
    wp_enqueue_style( 'custom-login', get_stylesheet_directory_uri() . '/css/login.css' );
}
add_action( 'login_enqueue_scripts', 'gfu_add_login_css' );






function gfu_redirect_to_protected_front($redirect_to, $request, $user) {

	if( is_user_logged_in() && in_array( 'filme_redakteur', (array) $user->roles ) && !in_array( 'administrator', (array) $user->roles )  ) {
		$redirect_to = get_site_url();
	}
	return $redirect_to;

}
add_filter('login_redirect', 'gfu_redirect_to_protected_front',10, 3);



function gfu_remove_admin_bar() {
	if( is_user_logged_in() ) {
		$user = wp_get_current_user();
		if ( in_array( 'filme_redakteur', (array) $user->roles ) && !in_array( 'administrator', (array) $user->roles ) ) {
			show_admin_bar(false);
		}
	}
}
add_action('after_setup_theme', 'gfu_remove_admin_bar');

