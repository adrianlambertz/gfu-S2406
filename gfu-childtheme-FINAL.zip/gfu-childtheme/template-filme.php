<?php 
/* Template Name: Filmauflistung */ 


get_header();
?>

	<main id="primary" class="site-main">

		<?php
            $args = array(
                'post_type' => 'movie',
                'limit' => -1
            );
            
            $movies = new WP_Query($args);
            
            if( $movies->have_posts() ) :
                echo '<ul>';
                while( $movies->have_posts() ) : $movies->the_post();
                    echo '<li><a href="' . get_permalink() . '" title="' . get_the_title() . '">' . get_the_title() . '</a></li>';
                endwhile;
                echo '</ul>';
            endif;
            wp_reset_postdata();
		?>

	</main><!-- #main -->

<?php
get_footer();



