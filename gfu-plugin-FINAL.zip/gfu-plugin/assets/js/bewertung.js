jQuery(function ($) {

    var rate = $('#rate_movie');

    rate.on('submit', function (e) {
        e.preventDefault();

        var rating = rate.find('select').val();
        var post_id = rate.find('#post_id_to_rate').val();

        $.ajax({
            url: bewertung_ajax_object.ajax_url,
            method: 'POST',
            data: {
                'action': 'rate_movies',
                'rating': rating,
                'post_id': post_id,
                'nonce': bewertung_ajax_object.nonce
            },
            success: function (result) {
                try {

                    console.log(result);
                    if (result.status === 'OK') {
                        //rate.html('Danke für deine Bewertung.');
                    } else {
                        rate.append('Etwas ist schiefgelaufen, bitte erneut versuchen.');
                    }
                } catch (error) {
                    console.error('Fehler beim Parsen der JSON-Daten: ' + error.message);
                    rate.append('Ein Fehler ist aufgetreten. Bitte versuche es später erneut.');
                }
            },
            error: function (xhr, status, error) {
                console.error('AJAX-Fehler: ' + error);
                rate.append('Ein AJAX-Fehler ist aufgetreten. Bitte versuche es später erneut.');
            }
        });
    });
});
