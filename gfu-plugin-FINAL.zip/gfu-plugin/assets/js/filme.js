jQuery(function($){

    const filter = $('#filter');

    filter.on('change submit',function(e){
	    e.preventDefault();

        let taxonomies = filter.find('.taxonomy-filter');
        
        let tax_data = {};
        if( taxonomies.length ) {
            taxonomies.each(function(){
                let el = $(this);
                if( el.val() ) {
                    tax_data[el.attr('id')] = el.val();
                }
            });
        }
        let titel = filter.find('#titel').val();
        let sort = filter.find('#sort').val();

        $.ajax({
            url: ajax_filter_object.ajax_url,
	        method: 'POST',
            data: {
                'action': ajax_filter_object.action,
                'taxonomies': tax_data,
                'titel': titel,
                'sort': sort,
                'nonce': ajax_filter_object.nonce
            },
            success: function (result) {
                try {
                    console.log(result);
                    if (result.status === 'OK') {
                        var output = '<ul class="movies">';
                        for (let i = 0; i < result.posts.length; i++) {
                            let el = result.posts[i];
                            output += `<li>
                                        <a href="${el.permalink}" title="${el.title}">
                                        <img loading="lazy" src="${el.poster}" alt="${el.title}" />
                                        <h4>${el.title}</h4>
                                        <div>${el.year}</div>
                                        </a>
                                    </li>
                                    `;

                        }
                        output += '</ul>';
                    } else {
                        output = 'Keine Filme gefunden.';
                    }
                    $('#ergebnisse').html(output);
                } catch (error) {
                    console.error('Fehler beim Parsen der JSON-Daten: ' + error.message);
                    $('#ergebnisse').html('Ein Fehler ist aufgetreten. Bitte versuche es später erneut.');
                }
            }
        });
    });

    filter.trigger('change');
});