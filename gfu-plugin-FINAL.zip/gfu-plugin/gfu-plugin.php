<?php
/*
Plugin Name:  GFU Plugin
Plugin URI:   https://gfu.de
Description:  Unser kleines Plugin
Version:      1.0
Author:       Adrian Lambertz
License:      GPL2
License URI:  https://www.gnu.org/licenses/gpl-2.0.html
Text Domain:  gfu-plugin
Domain Path:  /languages
*/



// Definition der Konstanten GFU_PLUGIN_DIR, falls noch nicht definiert
if( !defined('GFU_PLUGIN_DIR_URL') ) {
	define('GFU_PLUGIN_DIR_URL', plugin_dir_url( __FILE__ ));
}
if( !defined('GFU_PLUGIN_DIR') ) {
	define('GFU_PLUGIN_DIR', dirname( plugin_basename( __FILE__ ) ));
}




/**
 * Option Pages
 */
require_once 'includes/register_default_options_page.php';
require_once 'includes/register_acf_options_page.php';

/**
 * Post Types und Taxonomies
 */
require_once 'includes/register_custom_post_types.php';
require_once 'includes/register_custom_taxonomies.php';

/**
 * Meta Felder
 */
require_once 'includes/register_meta_fields.php';

/**
 * Shortcodes
 */
require_once 'includes/register_shortcode.php';

/**
 * Assets
 */
require_once 'includes/enqueue_assets.php';

/**
 * AJAX Filterung
 */
require_once 'includes/ajax-filter.php';

/**
 * Custom SQL Queries
 */
require_once 'includes/custom_sql.php';

/**
 * Benutzerrollen und Capabilities
 */
require_once 'includes/register_capabilities_and_user_roles.php';

/**
 * Bewertungsfunktion
 */
require_once 'includes/add_rating_select_to_movies.php';
require_once 'includes/ajax-rating.php';
require_once 'includes/register_rating_metabox.php';

/**
 * Lokalisierung
 */
require_once 'includes/load_textdomain.php';


/**
 * Widget
 */
require_once 'includes/register_widget.php';

/**
 * Funktion zum Schreiben von Debug-Nachrichten in eine Log-Datei
 */
function debug_log( $msg ) {
    file_put_contents( ABSPATH . 'custom-debug.log' , print_r($msg,true));
}


