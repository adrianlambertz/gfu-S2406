<?php 

// Funktion zum Hinzufügen der Bewertungsauswahl zu Filmen
function add_rating_select_to_movies( $content ) {

    // Überprüfen, ob der Beitragstyp 'movie' ist und ob es sich um eine einzelne Seite handelt
    if( get_post_type() === 'movie' && is_single()  ) {
        // Bewertungsfrage hinzufügen
        $content .= '<h4>'.__('Wie bewertest du den Film?', 'gfu-plugin').'</h4>';
        $content .= '<strong>'.__('Bitte nur ein mal bewerten.', 'gfu-plugin').'</strong>';
        
        // Bewertungsformular hinzufügen
        $content .= '<form id="rate_movie">';
            $content .= '<input type="hidden" id="post_id_to_rate" value="'.get_the_id().'">';
            
            // Bewertungsauswahl hinzufügen
            $content .= '<select>';
                $content .= '<option value="1">&star;</option>';
                $content .= '<option value="2">&star;&star;</option>';
                $content .= '<option value="3">&star;&star;&star;</option>';
                $content .= '<option value="4">&star;&star;&star;&star;</option>';
                $content .= '<option value="5">&star;&star;&star;&star;&star;</option>';
            $content .= '</select>';
            
            // Bewertungsabschicken-Button hinzufügen
            $content .= '<input type="submit" value="'.__('Bewertung abschicken','gfu-plugin').'" />';
        $content .= '</form>';
    }

    // Den bearbeiteten Inhalt zurückgeben
    return $content;

}

// Den Filter auf den Inhalt anwenden
add_filter('the_content', 'add_rating_select_to_movies');