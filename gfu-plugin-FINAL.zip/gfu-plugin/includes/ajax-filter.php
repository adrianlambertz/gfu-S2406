<?php


// Funktion zum Filtern von Filmen durch Ajax-Aufruf
function filter_filme(){
    // Überprüfe Nonce
    if( !isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'ajax-nonce') )
        wp_die('Permission denied');

    // WP_Query-Argumente vorbereiten
    $args = array(
        'post_type' => 'movie', // Dein Custom Post Type
        'posts_per_page' => -1,  // Alle Filme abrufen
    );

    // Überprüfe und füge Taxonomien zur Abfrage hinzu
    if( isset($_POST['taxonomies']) && is_array( $_POST['taxonomies'] ) && !empty( $_POST['taxonomies'] ) ){
        foreach($_POST['taxonomies'] as $tax=>$value) {
            $args['tax_query'][] = array(
                'taxonomy' => sanitize_text_field($tax),
                'field' => 'slug',
                'terms' => sanitize_text_field($value)
            );
        }
    }

    // Füge Freitextsuche hinzu, wenn Titel angegeben ist
    if( isset($_POST['titel']) && $_POST['titel'] !== '' ){
        $args['s'] = sanitize_text_field($_POST['titel']);
    }

    // Sortierung
    if( isset($_POST['sort']) ){
        $chunks = explode('|', $_POST['sort']);
        if( count($chunks) == 2 && ( $chunks[1] == 'ASC' || $chunks[1] == 'DESC' ) ) {
            $args['meta_key'] = $chunks[0];
            $args['orderby'] = 'meta_value_num';
            $args['order'] = $chunks[1];
        }
    }

    // WP_Query erstellen
    $query = new WP_Query($args);

    // Ergebnisse als JSON vorbereiten
    $results = array();

    if($query->have_posts()):
        $results['status'] = 'OK';
        $results['posts'] = array();
        while($query->have_posts()) : $query->the_post();

            //debug_log($img);

            // Filminformationen holen und zur Ergebnisliste hinzufügen
            $medium_img = ( $img = get_field('movie_image') ) ? $img['sizes']['medium'] : false;
            $year = get_post_meta( get_the_id() , '_movie_jahr' , true);
            $results['posts'][] = array(
                'title' => get_the_title(),
                'permalink' => get_permalink(),
                'poster' => esc_url($medium_img),
                'year' => intval($year),
            );
        endwhile;
    else :
        $results['status'] = 'ERROR';
    endif;

    // Reset Postdata
    wp_reset_postdata();

    // Ergebnisse als JSON ausgeben
    wp_send_json($results);

}

// Ajax-Aktionen registrieren
add_action('wp_ajax_filter_filme', 'filter_filme');
add_action('wp_ajax_nopriv_filter_filme', 'filter_filme');
