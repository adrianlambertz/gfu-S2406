<?php


function rate_movies(){

    // Überprüfe Nonce
    if( !isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'bewertung-ajax-nonce') )
        wp_die('Permission denied'); // Wenn die Nonce-Überprüfung fehlschlägt, wird die Ausführung gestoppt und "Permission denied" ausgegeben.

    $post_id = isset($_POST['post_id']) ? intval($_POST['post_id']) : 0;
    
    // Überprüfe, ob der Beitragstyp 'movie' ist
    if( get_post_type($post_id) !== 'movie' ) {
        echo json_encode( array( 'status' => 'ERROR' ) ); // Wenn nicht, wird ein JSON mit Fehlerstatus ausgegeben.
        wp_die();
    }

    $rating = isset($_POST['rating']) ? intval($_POST['rating']) : 0;

    // Überprüfe, ob die Bewertung im erlaubten Bereich von 0 bis 5 liegt
    if ($rating < 0 || $rating > 5) {
        echo json_encode(array('status' => 'ERROR')); // Wenn nicht, wird ein JSON mit Fehlerstatus ausgegeben.
        wp_die();
    }

    $count_votes = get_post_meta( $post_id, 'count_votes', true ) ?: 0;
    $avg_rating = get_post_meta( $post_id, 'avg_rating', true ) ?: 0;

    // Berechne den neuen Durchschnitt
    $new_avg = round( ($count_votes * $avg_rating + $rating) / ($count_votes + 1) * 100 ) / 100;

    // Aktualisiere die Metadaten des Filmes
    update_post_meta( $post_id, 'count_votes', $count_votes+1 );
    update_post_meta( $post_id, 'avg_rating', $new_avg );

    // Ergebnisse als JSON ausgeben
    wp_send_json(
        array(
            'status' => 'OK',
            'newAverage' => $new_avg
        )
    );

}

add_action('wp_ajax_rate_movies', 'rate_movies'); // Funktion wird für angemeldete Benutzer aufgerufen
add_action('wp_ajax_nopriv_rate_movies', 'rate_movies'); // Funktion wird auch für ausgeloggte Benutzer aufgerufen
