<?php


function show_custom_query() {

    global $wpdb;

    $query = $wpdb->prepare("SELECT * FROM {$wpdb->prefix}posts WHERE post_type = %s", 'movie');
    $result = $wpdb->query($query);
    
    //print_r($result);
}

// add_action('wp_head', 'show_custom_query');