<?php

function gfu_enqueue_filme_assets() {

    // prüfe ob der shortcode [movie_filter] im content ist
    if( has_shortcode( get_the_content(), 'movie_filter') ) {

        // Die CSS-Datei registrieren und einbinden
        wp_register_style('filme-css', GFU_PLUGIN_DIR_URL . 'assets/css/filme.css' , array(), '1.0', 'all');
        wp_enqueue_style('filme-css');

        // Die JS-Datei registrieren und einbinden
        wp_register_script('filme-js', GFU_PLUGIN_DIR_URL . 'assets/js/filme.js' , array('jquery'), '1.0', 'true');
        wp_enqueue_script('filme-js');
        

        wp_localize_script('filme-js', 'ajax_filter_object', 
            array(
                'ajax_url' => admin_url('admin-ajax.php'), 
                'nonce' => wp_create_nonce('ajax-nonce'),
                'action' => 'filter_filme',
            )
        ); 
    }


    if( get_post_type() === 'movie' ) {
        wp_register_script('bewertung-js', GFU_PLUGIN_DIR_URL . 'assets/js/bewertung.js' , array('jquery'), '1.0', 'true');
        wp_enqueue_script('bewertung-js');

        wp_localize_script('bewertung-js', 'bewertung_ajax_object', 
            array(
                'ajax_url' => admin_url('admin-ajax.php'), 
                'nonce' => wp_create_nonce('bewertung-ajax-nonce')
            )
        );
    }

}

// Die Funktion beim Laden der WordPress-Seite aufrufen
add_action('wp_enqueue_scripts', 'gfu_enqueue_filme_assets');



