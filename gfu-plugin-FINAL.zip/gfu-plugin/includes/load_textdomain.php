<?php

// Lade die MO/PO Übersetzungsdateien automatisch aus dem /languages/ Ordner
load_plugin_textdomain( 'gfu-plugin', false, GFU_PLUGIN_DIR . '/languages/' );
