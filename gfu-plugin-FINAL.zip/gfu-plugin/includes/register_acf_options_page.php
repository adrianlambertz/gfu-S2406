<?php


add_action('acf/init', 'gfu_eigene_options_page');
function gfu_eigene_options_page() {

    // Check function exists.
    if( function_exists('acf_add_options_page') ) {

        // Register options page.
        $option_page = acf_add_options_page(array(
            'page_title'    => __('Öffnungszeiten'),
            'menu_title'    => __('Öffnungszeiten'),
            'menu_slug'     => 'theme-general-settings',
            'capability'    => 'edit_posts',
            'redirect'      => false
        ));

    }
}
