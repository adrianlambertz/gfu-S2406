<?php

// Hook, um Code beim Initialisieren von WordPress auszuführen
add_action('init', 'benutzerrolle_filme_redakteur', 100);
function benutzerrolle_filme_redakteur() {
        // Erstelle die Rolle "Filme-Redakteur"
        add_role(
            'filme_redakteur',      // Rolle mit dem Namen 'filme_redakteur' erstellen
            __('Filme-Redakteur'),  // Anzeigename der Rolle für die Administration
            array(
                'read'         => true,        // Erlaubt dem Benutzer das Betreten des Backends
                'edit_movies'  => true,        // Erlaubt dem Benutzer das Bearbeiten von Filmen
                'read_movie'   => true,        // Erlaubt dem Benutzer das Lesen von Filmen
            )
        );
}




add_action('admin_init', 'meine_custom_capabilities');

function meine_custom_capabilities() {
    // Hole die Administrator-Rolle
    $admin_role = get_role('administrator');

    // Füge die gewünschten Capabilities hinzu
    $admin_role->add_cap('edit_movie');
    $admin_role->add_cap('read_movie');
    $admin_role->add_cap('delete_movie');
    $admin_role->add_cap('edit_movies');
    $admin_role->add_cap('edit_others_movie');
    $admin_role->add_cap('publish_movies');
    $admin_role->add_cap('read_private_movies');
    
    
    $admin_role->remove_cap('read_private_movies');
}