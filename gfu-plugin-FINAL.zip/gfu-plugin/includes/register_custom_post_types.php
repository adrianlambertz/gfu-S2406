<?php

if ( ! function_exists('gfu_erstelle_filme_cpt') ) {

    function gfu_erstelle_filme_cpt() {

        $labels = array(
            'name'                  => _x( 'Filme', 'Post Type General Name', 'gfu-plugin' ),
            'singular_name'         => _x( 'Film', 'Post Type Singular Name', 'gfu-plugin' ),
            'menu_name'             => __( 'Filme', 'gfu-plugin' ),
            'name_admin_bar'        => __( 'Filme', 'gfu-plugin' ),
            'archives'              => __( 'Film Archiv', 'gfu-plugin' ),
            'attributes'            => __( 'Filme Attribute', 'gfu-plugin' ),
            'parent_item_colon'     => __( 'Übergeordneter Film', 'gfu-plugin' ),
            'all_items'             => __( 'Alle Filme', 'gfu-plugin' ),
            'add_new_item'          => __( 'Neuen Film hinzufügen', 'gfu-plugin' ),
            'add_new'               => __( 'Film hinzufügen', 'gfu-plugin' ),
            'new_item'              => __( 'Neuer Film', 'gfu-plugin' ),
            'edit_item'             => __( 'Film bearbeiten', 'gfu-plugin' ),
            'update_item'           => __( 'Film aktualisieren', 'gfu-plugin' ),
            'view_item'             => __( 'Film ansehen', 'gfu-plugin' ),
            'view_items'            => __( 'Filme ansehen', 'gfu-plugin' ),
            'search_items'          => __( 'Filme suchen', 'gfu-plugin' ),
            'not_found'             => __( 'Nichts gefunden', 'gfu-plugin' ),
            'not_found_in_trash'    => __( 'Nichts im Papierkorb gefunden', 'gfu-plugin' ),
            'featured_image'        => __( 'Filmposter', 'gfu-plugin' ),
            'set_featured_image'    => __( 'Filmposter festlegen', 'gfu-plugin' ),
            'remove_featured_image' => __( 'Filmposter entfernen', 'gfu-plugin' ),
            'use_featured_image'    => __( 'Als Filmposter nutzen', 'gfu-plugin' ),
            'insert_into_item'      => __( 'In Film einfügen', 'gfu-plugin' ),
            'uploaded_to_this_item' => __( 'Zu diesem Film hochgeladen', 'gfu-plugin' ),
            'items_list'            => __( 'Items list', 'gfu-plugin' ),
            'items_list_navigation' => __( 'Items list navigation', 'gfu-plugin' ),
            'filter_items_list'     => __( 'Filter items list', 'gfu-plugin' ),
        );
        $capabilities = array(
            'edit_post'             => 'edit_movie',
            'read_post'             => 'read_movie',
            'delete_post'           => 'delete_movie',
            'edit_posts'            => 'edit_movies',
            'edit_others_posts'     => 'edit_others_movie',
            'publish_posts'         => 'publish_movies',
            'read_private_posts'    => 'read_private_movies',
        );
        $args = array(
            'label'                 => __( 'Film', 'gfu-plugin' ),
            'description'           => __( 'Filme für die GFU Videothek', 'gfu-plugin' ),
            'labels'                => $labels,
            'supports'              => array( 'title', 'editor' ),
            'taxonomies'            => array( 'schauspieler', 'genre' ),
            'hierarchical'          => false,
            'public'                => true,
            'show_ui'               => true,
            'show_in_menu'          => true,
            'menu_position'         => 5,
            'menu_icon'             => 'dashicons-video-alt2',
            'show_in_admin_bar'     => true,
            'show_in_nav_menus'     => true,
            'can_export'            => true,
            'has_archive'           => true,
            'exclude_from_search'   => false,
            'publicly_queryable'    => true,
            'capabilities'          => $capabilities,
        );
        register_post_type( 'movie', $args );

    }
    add_action( 'init', 'gfu_erstelle_filme_cpt', 0 );

}

