<?php

if ( ! function_exists('gfu_erstelle_genre_taxonomie') ) {

    function gfu_erstelle_genre_taxonomie() {
        $labels = array(
            'name' => __('Genres', 'gfu-plugin'),
            'singular_name' => __('Genre', 'gfu-plugin'),
            'search_items' => __('Genre suchen', 'gfu-plugin'),
            'all_items' => __('Alle Genres', 'gfu-plugin'),
            'edit_item' => __('Genre bearbeiten', 'gfu-plugin'),
            'update_item' => __('Genre aktualisieren', 'gfu-plugin'),
            'add_new_item' => __('Neues Genre hinzufügen', 'gfu-plugin'),
            'new_item_name' => __('Neuer Genre-Name', 'gfu-plugin'),
            'menu_name' => __('Genres', 'gfu-plugin'),
        );

        $args = array(
            'hierarchical' => true,
            'labels' => $labels,
            'show_ui' => true,
            'show_admin_column' => true,
            'query_var' => true,
            'rewrite' => array('slug' => 'genre'), // Hier kannst du den Slug anpassen
            'capabilities' => array(
                'manage_terms' => 'manage_movie_terms', // Eigene Capability zum Verwalten der Taxonomie
                'edit_terms' => 'edit_movie_terms',
                'delete_terms' => 'delete_movie_terms',
                'assign_terms' => 'assign_movie_terms',
            ),
        );
        register_taxonomy('genre', 'movie', $args);
    }
    add_action('init', 'gfu_erstelle_genre_taxonomie');

}

if ( ! function_exists('gfu_erstelle_schauspieler_taxonomie') ) {

    function gfu_erstelle_schauspieler_taxonomie() {
        $labels = array(
            'name' => __('Schauspieler', 'gfu-plugin'),
            'singular_name' => __('Schauspieler', 'gfu-plugin'),
            'search_items' => __('Schauspieler suchen', 'gfu-plugin'),
            'all_items' => __('Alle Schauspieler', 'gfu-plugin'),
            'edit_item' => __('Schauspieler bearbeiten', 'gfu-plugin'),
            'update_item' => __('Schauspieler aktualisieren', 'gfu-plugin'),
            'add_new_item' => __('Neuen Schauspieler hinzufügen', 'gfu-plugin'),
            'new_item_name' => __('Neuer Schauspieler-Name', 'gfu-plugin'),
            'menu_name' => __('Schauspieler', 'gfu-plugin'),
        );

        $args = array(
            'hierarchical' => false, // Nicht hierarchisch, da Schauspieler nicht hierarchisch gruppiert sind
            'labels' => $labels,
            'show_ui' => true,
            'show_admin_column' => true,
            'query_var' => true,
            'rewrite' => array('slug' => 'schauspieler'), // Hier kannst du den Slug anpassen
            'capabilities' => array(
                'manage_terms' => 'manage_movie_terms', // Eigene Capability zum Verwalten der Taxonomie
                'edit_terms' => 'edit_movie_terms',
                'delete_terms' => 'delete_movie_terms',
                'assign_terms' => 'assign_movie_terms',
            ),
        );

        register_taxonomy('schauspieler', 'movie', $args);
    }

    // Die Taxonomie beim Initialisieren des WordPress hinzufügen
    add_action('init', 'gfu_erstelle_schauspieler_taxonomie');

}
