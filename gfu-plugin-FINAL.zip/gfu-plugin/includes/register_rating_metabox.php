<?php

// Funktion zum Hinzufügen eines neuen Post-Meta-Felds für das Jahr
function gfu_hinzufuegen_movie_rating_metabox() {
    add_meta_box(
        'movie_rating_meta',
        'Bewertung',
        'gfu_zeige_movie_rating',
        'movie',
        'side',
        'default'
    );
}
add_action('add_meta_boxes', 'gfu_hinzufuegen_movie_rating_metabox');

// Funktion zum Anzeigen des Meta-Box-Inhalts
function gfu_zeige_movie_rating($post) {
    // Hole den vorhandenen Wert des Meta-Felds
    $avg_rating = get_post_meta($post->ID, 'avg_rating', true);
    $count_votes = get_post_meta($post->ID, 'count_votes', true);

    echo '<div>Durchschnittliche Bewertung von ' . esc_attr($avg_rating) . '/5</div>';
    echo '<i>Score basiert auf ' . esc_attr($count_votes) . ' Votes</i>';
}