<?php


function gfu_movie_liste_shortcode($atts) {
    // Standardattribute für den Shortcode festlegen
    $atts = shortcode_atts(
        array(
            'schauspieler' => '',
            'genre' => '',
        ),
        $atts,
        'movie_list'
    );

    // WP_Query-Argumente erstellen
    $query_args = array(
        'post_type' => 'movie',
        'posts_per_page' => -1, // Alle Filme anzeigen
    );

    // Taxonomie-Parameter hinzufügen, falls vorhanden
    if ($atts['schauspieler']) {
        $query_args['tax_query'][] = array(
            'taxonomy' => 'schauspieler',
            'field' => 'slug',
            'terms' => $atts['schauspieler'],
        );
    }

    if ($atts['genre']) {
        $query_args['tax_query'][] = array(
            'taxonomy' => 'genre',
            'field' => 'slug',
            'terms' => $atts['genre'],
        );
    }

    // WP_Query ausführen
    $movie_query = new WP_Query($query_args);


    // Liste der Filmtitel erstellen
    $movie_list = '<ul>';

    if ($movie_query->have_posts()) {
        while ($movie_query->have_posts()) {
            $movie_query->the_post();
            $movie_list .= '<li>';
		$movie_list .= '<a href="' . get_permalink() . '" title="' . get_the_title() . '">';
			if( $img = get_field('movie_image') ):
				$movie_list .= '<img src="'.$img['sizes']['medium'].'" alt="'.$img['title'].'" />';
			endif; 
		$movie_list .= '</a>';
	    $movie_list .= '</li>';


        }
        wp_reset_postdata();
    } else {
        $movie_list .= '<li>Keine Filme gefunden.</li>';
    }

    $movie_list .= '</ul>';

    return $movie_list;
}

// Shortcode registrieren
add_shortcode('movie_list', 'gfu_movie_liste_shortcode');






function gfu_greetings_in_shortcode($atts) {
    // Standardwerte für die Attribute festlegen
    $atts = shortcode_atts(
        array(
            'name' => 'Besucher',
        ),
        $atts,
        'greeting'
    );

    // Den Gruß-Text mit dem dynamischen Namen erstellen
    $content = '<div class="greeting"><i>Hallo, ' . esc_html($atts['name']) . '! Wie gehts?</i></div>';
    return $content;
}
add_shortcode('greeting', 'gfu_greetings_in_shortcode');







function movie_filter_func($atts) {

    $attributes = shortcode_atts(
        array(
            'taxonomies' => 'genre,schauspieler',
        ),
        $atts,
        'movie_filter'
    );

    $taxonomies = explode(',', $attributes['taxonomies']);

    $content = '<form id="filter" action="#" method="post">';

        if( !empty($taxonomies) ) {
            foreach ($taxonomies as $taxonomy) {
                
                // Frage alle verfügbaren Begriffe der angegebenen Taxonomie ab
                $terms = get_terms($taxonomy);
                if( !is_wp_error($terms) ) {
                    $content .= '<select class="taxonomy-filter" id="' . esc_attr($taxonomy) . '" name="' . esc_attr($taxonomy) . '">';
                        $content .= '<option value="">Alle</option>';

                        foreach ($terms as $term) {
                            $content .= '<option value="' . esc_attr($term->slug) . '">' . esc_html($term->name) . '</option>';
                        }

                    $content .= '</select>';
                }
            }
        }

        $content .= '<input type="text" id="titel" name="titel" placeholder="Titel suchen">';
        $content .= '<input type="submit" id="apply_filters" name="apply_filters" value="Filter anwenden" />';

        $content .= '<select id="sort" name="sort">';
            $content .= '<option value="_movie_jahr|ASC">Erscheinungsdatum alt -> neu</option>';
            $content .= '<option value="_movie_jahr|DESC">Erscheinungsdatum neu -> alt</option>';
            $content .= '<option value="avg_rating|ASC">Bewertung niedrig -> hoch</option>';
            $content .= '<option value="avg_rating|DESC">Bewertung hoch -> niedrig</option>';
        $content .= '</select>';

    $content .= '</form>';
    $content .= '<div id="ergebnisse"></div>';

    return $content;

}

add_shortcode('movie_filter', 'movie_filter_func');





?>
