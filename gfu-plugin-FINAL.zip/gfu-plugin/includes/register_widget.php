<?php

class Textarea_URL_Widget extends WP_Widget {

    // Konstruktor
    public function __construct() {
        parent::__construct(
            'textarea_url_widget', // Widget-ID
            'Textarea und URL Widget', // Widget-Name
            array('description' => 'Ein Widget mit Textarea und URL') // Widget-Beschreibung
        );
    }

    // Ausgabe des Widgets auf der Website
    public function widget($args, $instance) {

        echo $args['before_widget'];
        echo $args['before_title'] . esc_html($instance['title']) . $args['after_title'];

        // Textarea-Inhalt ausgeben
        echo '<p>' . esc_textarea($instance['textarea_content']) . '</p>';

        // URL ausgeben
        if (!empty($instance['url'])) {
            echo '<p><a href="' . esc_url($instance['url']) . '">Weitere Informationen</a></p>';
        }

        echo $args['after_widget'];

    }

    // Formular zur Widget-Konfiguration im Admin-Bereich
    public function form($instance) {
        $title = !empty($instance['title']) ? $instance['title'] : 'Widget Titel';
        $textarea_content = !empty($instance['textarea_content']) ? $instance['textarea_content'] : '';
        $url = !empty($instance['url']) ? $instance['url'] : '';

        // Widget-Titel
        echo '<p><label for="' . $this->get_field_id('title') . '">Widget Titel:</label>';
        echo '<input class="widefat" id="' . $this->get_field_id('title') . '" name="' . $this->get_field_name('title') . '" type="text" value="' . esc_attr($title) . '"></p>';

        // Textarea
        echo '<p><label for="' . $this->get_field_id('textarea_content') . '">Textarea-Inhalt:</label>';
        echo '<textarea class="widefat" id="' . $this->get_field_id('textarea_content') . '" name="' . $this->get_field_name('textarea_content') . '">' . esc_textarea($textarea_content) . '</textarea></p>';

        // URL
        echo '<p><label for="' . $this->get_field_id('url') . '">URL:</label>';
        echo '<input class="widefat" id="' . $this->get_field_id('url') . '" name="' . $this->get_field_name('url') . '" type="url" value="' . esc_url($url) . '"></p>';
    }

    
    // Speichern der Widget-Einstellungen
    public function update($new_instance, $old_instance) {
        $instance = array();
        $instance['title'] = sanitize_text_field($new_instance['title']);
        $instance['textarea_content'] = sanitize_textarea_field($new_instance['textarea_content']);
        $instance['url'] = esc_url_raw($new_instance['url']);
        return $instance;
    }
}

// Widget registrieren
function register_textarea_url_widget() {
    register_widget('Textarea_URL_Widget');
}
add_action('widgets_init', 'register_textarea_url_widget');

?>
